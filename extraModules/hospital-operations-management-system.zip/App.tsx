
import React, { useState } from 'react';
import LandingPage from './components/LandingPage';
import OperationsDashboard from './components/OperationsDashboard';
import QualityDashboard from './components/QualityDashboard';
import ComplaintsDashboard from './components/ComplaintsDashboard';
import ITDashboard from './components/ITDashboard';
import MortuaryDashboard from './components/MortuaryDashboard';
import TransplantDashboard from './components/TransplantDashboard';
import CSSDDashboard from './components/CSSDDashboard';
import LaundryDashboard from './components/LaundryDashboard';
import HRDashboard from './components/HRDashboard';
import PerformanceDashboard from './components/PerformanceDashboard';
import NarcoticsDashboard from './components/NarcoticsDashboard';
import HousekeepingDashboard from './components/HousekeepingDashboard';
import ComplianceDashboard from './components/ComplianceDashboard';
import AVDashboard from './components/AVDashboard';

import {
    feedbackData,
    labResultsData,
    dischargeData,
    transcriptionData,
    licenseData,
    complianceTaskData,
    avContentData,
    housekeepingTaskData,
    wasteCollectionData,
    complaintsData,
    itSupportTicketData,
    mortuaryCaseData,
    transplantCaseData,
    cssdRequestData,
    laundryRequestData,
    employeeData,
    trainingSessionData,
    performanceReviewData,
    narcoticsInventoryData,
    narcoticsLogData,
} from './data';
import { Complaint, CSSDRequest, Employee, HousekeepingTask, ITSupportTicket, LaundryRequest, MortuaryCase, Narcotic, PerformanceReview, TransplantCase, TrainingSession, WasteCollection, AVContent, NarcoticLog, License, PerformanceReview as PerformanceReviewType, Feedback } from './types';


const App: React.FC = () => {
    const [activeCategoryKey, setActiveCategoryKey] = useState<string | null>(null);

    // This is a simplified state management for demonstration.
    // In a real app, this would be handled by a more robust state management solution.
    const [complaints, setComplaints] = useState(complaintsData);
    const [itTickets, setItTickets] = useState(itSupportTicketData);
    const [mortuaryCases, setMortuaryCases] = useState(mortuaryCaseData);
    const [transplantCases, setTransplantCases] = useState(transplantCaseData);
    const [cssdRequests, setCssdRequests] = useState(cssdRequestData);
    const [laundryRequests, setLaundryRequests] = useState(laundryRequestData);
    const [employees, setEmployees] = useState(employeeData);
    const [trainingSessions, setTrainingSessions] = useState(trainingSessionData);
    const [performanceReviews, setPerformanceReviews] = useState(performanceReviewData);
    const [narcotics, setNarcotics] = useState(narcoticsInventoryData);
    const [narcoticsLogs, setNarcoticsLogs] = useState(narcoticsLogData);
    const [housekeepingTasks, setHousekeepingTasks] = useState(housekeepingTaskData);
    const [wasteCollections, setWasteCollections] = useState(wasteCollectionData);
    const [licenses, setLicenses] = useState(licenseData);
    const [complianceTasks, setComplianceTasks] = useState(complianceTaskData);
    const [avContent, setAvContent] = useState(avContentData);


    const handleBack = () => setActiveCategoryKey(null);

    const renderDashboard = () => {
        switch (activeCategoryKey) {
            case 'operations':
                return <OperationsDashboard onBack={handleBack} />;
            case 'quality':
                return <QualityDashboard />;
            case 'admin':
                return (
                    <div className="p-8">
                        <button onClick={handleBack} className="text-gray-300 hover:text-white mb-4">&larr; Back</button>
                        <HRDashboard employees={employees} sessions={trainingSessions} onAddEmployee={(e) => setEmployees(prev => [...prev, {...e, id: `EMP-${Date.now()}`, status: 'Active'}])} onScheduleTraining={(s) => setTrainingSessions(prev => [...prev, {...s, id: `TS-${Date.now()}`}])}/>
                        <ITDashboard tickets={itTickets} onAddTicket={(t) => setItTickets(prev => [...prev, t])} />
                        <ComplaintsDashboard complaints={complaints} onAddComplaint={(c) => setComplaints(prev => [...prev, c])} />
                    </div>
                )
            case 'support':
                return (
                     <div className="p-8">
                        <button onClick={handleBack} className="text-gray-300 hover:text-white mb-4">&larr; Back</button>
                        <HousekeepingDashboard tasks={housekeepingTasks} collections={wasteCollections} onAddTask={(t) => setHousekeepingTasks(prev => [...prev, t])} onAddCollection={(c) => setWasteCollections(prev => [...prev, c])} />
                        <CSSDDashboard requests={cssdRequests} onAddRequest={(r) => setCssdRequests(prev => [...prev, {...r, id: `CSSD-${Date.now()}`, requestDate: new Date().toLocaleDateString(), status: 'Pending'}])} />
                        <LaundryDashboard requests={laundryRequests} onAddRequest={() => { /* Add logic */ }} />
                    </div>
                )
            case 'specialized':
                return (
                    <div className="p-8">
                        <button onClick={handleBack} className="text-gray-300 hover:text-white mb-4">&larr; Back</button>
                        <MortuaryDashboard cases={mortuaryCases} onAddCase={() => {/* Add logic */}}/>
                        <TransplantDashboard cases={transplantCases} onAddCase={() => {/* Add logic */}}/>
                        <NarcoticsDashboard inventory={narcotics} logs={narcoticsLogs} onAddNarcotic={(n) => setNarcotics(prev => [...prev, {...n, id: `N-${Date.now()}`}])} onLogTransaction={(l) => setNarcoticsLogs(prev => [...prev, {...l, id: `LOG-${Date.now()}`}])} />
                    </div>
                )
            case 'compliance':
                 return (
                    <div className="p-8">
                        <button onClick={handleBack} className="text-gray-300 hover:text-white mb-4">&larr; Back</button>
                        <ComplianceDashboard licenses={licenses} tasks={complianceTasks} />
                        <AVDashboard content={avContent} onAddContent={(c) => setAvContent(prev => [...prev, {...c, id: `AV-${Date.now()}`, uploadDate: new Date().toLocaleDateString(), status: 'Processing'}])}/>
                        <PerformanceDashboard reviews={performanceReviews} onStartReview={(r) => setPerformanceReviews(prev => [...prev, {...r, id: `PR-${Date.now()}`, status: 'Pending', summary: ''}])} />
                    </div>
                )
            default:
                return (
                    <div className="p-8 text-white">
                        <button onClick={handleBack} className="text-gray-300 hover:text-white mb-4">&larr; Back</button>
                        <h1 className="text-2xl font-bold">{activeCategoryKey} Dashboard</h1>
                        <p>This module is under construction.</p>
                    </div>
                );
        }
    };

    return (
        <div className="bg-gray-900 min-h-screen">
            {activeCategoryKey ? renderDashboard() : <LandingPage onSelectCategory={setActiveCategoryKey} />}
        </div>
    );
};

export default App;
