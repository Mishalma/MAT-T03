
import React from 'react';
import { serviceCategories } from '../navigation';
import { ServiceCategory } from '../types';

interface LandingPageProps {
    onSelectCategory: (key: string) => void;
}

const CategoryCard: React.FC<{ categoryKey: string, category: ServiceCategory; onClick: () => void }> = ({ categoryKey, category, onClick }) => (
    <div
        onClick={onClick}
        className="group bg-gray-800 hover:bg-gray-700/50 border border-gray-700 rounded-lg p-6 cursor-pointer transition-all duration-300 ease-in-out transform hover:-translate-y-1"
    >
        <div className="flex items-start justify-between">
            <div className="flex-shrink-0 p-3 bg-gray-700/50 rounded-lg">
                <category.icon className="h-8 w-8 text-blue-500 group-hover:text-blue-400 transition-colors" />
            </div>
             <div className="text-2xl text-gray-600 group-hover:text-white transition-all group-hover:translate-x-1">
                &rarr;
            </div>
        </div>
        <div className="mt-4">
            <h3 className="text-lg font-semibold text-gray-100">{category.name}</h3>
            <p className="mt-1 text-sm text-gray-400">{category.description}</p>
        </div>
    </div>
);

const LandingPage: React.FC<LandingPageProps> = ({ onSelectCategory }) => {
    return (
        <div className="min-h-screen bg-gray-900 text-white p-8">
            <header className="text-center mb-12">
                <h1 className="text-4xl font-bold tracking-tight">Hospital Management System</h1>
                <p className="mt-2 text-lg text-gray-400">Select a service category to begin.</p>
            </header>
            <main>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
                    {Object.entries(serviceCategories).map(([key, category]) => (
                        <CategoryCard key={key} categoryKey={key} category={category} onClick={() => onSelectCategory(key)} />
                    ))}
                </div>
            </main>
        </div>
    );
};

export default LandingPage;
