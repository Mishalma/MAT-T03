
import React from 'react';

const PurchaseDashboard = () => {
    return (
        <div className="text-white">
            <h1 className="text-2xl font-bold">Purchase Dashboard</h1>
            <p>This module is under construction.</p>
        </div>
    );
};

export default PurchaseDashboard;
