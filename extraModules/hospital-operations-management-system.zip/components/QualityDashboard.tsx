
import React from 'react';

const QualityDashboard = () => {
    return (
        <div className="text-white">
            <h1 className="text-2xl font-bold">Quality Dashboard</h1>
            <p>This module is under construction.</p>
        </div>
    );
};

export default QualityDashboard;
