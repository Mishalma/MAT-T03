
import React from 'react';

const AccreditationDashboard = () => {
    return (
        <div className="text-white">
            <h1 className="text-2xl font-bold">Accreditation Dashboard</h1>
            <p>This module is under construction.</p>
        </div>
    );
};

export default AccreditationDashboard;
