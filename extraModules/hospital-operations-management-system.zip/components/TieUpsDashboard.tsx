
import React from 'react';

const TieUpsDashboard = () => {
    return (
        <div className="text-white">
            <h1 className="text-2xl font-bold">Tie-Ups Dashboard</h1>
            <p>This module is under construction.</p>
        </div>
    );
};

export default TieUpsDashboard;
